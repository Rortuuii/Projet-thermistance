
#include <Arduino.h>
#include "lorae5.h"
#include "config_application.h"
#include "config_board.h"

uint8_t sizePayloadUp = 2;
uint8_t sizePayloadDown = 0;

uint8_t payloadUp[20] = {0};
uint8_t payloadDown[20] = {0};

LORAE5 lorae5(devEUI, appEUI, appKey, devAddr, nwkSKey, appSKey);

// Remplacez `u_int16_t` par `int16_t` pour permettre des valeurs signées
const int Pin = 39;
float sensorData = 0;
int16_t sensorData_int = 0;

void setup() {
  lorae5.setup_hardware(&Debug_Serial, &LoRa_Serial);
  lorae5.setup_lorawan(REGION, ACTIVATION_MODE, CLASS, SPREADING_FACTOR, ADAPTIVE_DR, CONFIRMED, PORT_UP, SEND_BY_PUSH_BUTTON, FRAME_DELAY);
  lorae5.printInfo();

  if(ACTIVATION_MODE == OTAA){
    Debug_Serial.println("Join Procedure in progress...");
    while(lorae5.join() == false);
    delay(2000);
  }
}

void processDownlink() {
  // Traitement du message reçu si nécessaire
}

void loop() {
  // Convertir la valeur float en entier 16 bits signé
  sensorData_int = (-0.0155*analogRead(Pin)+59.241)*100;  // Par exemple, -23.75 devient -2375

  payloadUp[0] = highByte(sensorData_int); 
  payloadUp[1] = lowByte(sensorData_int);

  // Envoyer les données
  lorae5.sendData(payloadUp, sizePayloadUp);

  // Vérifier la réception du downlink
  if (lorae5.awaitForDownlinkClass_A(payloadDown, &sizePayloadDown) == RET_DOWNLINK) {
    processDownlink();
  };

  // Mode basse consommation
  lorae5.sleep();
}